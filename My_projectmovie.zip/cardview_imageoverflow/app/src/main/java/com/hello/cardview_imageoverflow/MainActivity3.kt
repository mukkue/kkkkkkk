package com.hello.cardview_imageoverflow

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.hello.cardview_imageoverflow.adapters.LoginAdapter
import com.hello.cardview_imageoverflow.fragment.LoginFragment
import com.hello.cardview_imageoverflow.fragment.RegisterFragment

class MainActivity3 : AppCompatActivity() {

    var tabTitle = arrayOf("Login","Register")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        var tabLayout:TabLayout=findViewById(R.id.tab_layout);
        var pager = findViewById<ViewPager2>(R.id.viewpager_signup)

        pager.adapter=LoginAdapter(supportFragmentManager, lifecycle)
        //supportFragmentManager.beginTransaction().add(R.id.frame,LoginFragment()).commit()
        //supportFragmentManager.beginTransaction().add(R.id.frame,RegisterFragment()).commit()
            //supportFragmentManager.beginTransaction().add(R.id.frame,ForgetFragment()).commit()


        TabLayoutMediator (tabLayout, pager) {
            tab, position ->
            tab.text = tabTitle[position]
        }.attach()

    }
}