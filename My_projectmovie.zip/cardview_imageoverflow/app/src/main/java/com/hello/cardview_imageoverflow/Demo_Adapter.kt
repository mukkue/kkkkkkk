package com.hello.cardview_imageoverflow

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.media.Image
import android.view.ContextMenu
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class Demo_Adapter(var mlist:List<ItemViewModel>,var context: Context):RecyclerView.Adapter<Demo_Adapter.MyViewHolder>() {
    class MyViewHolder(ItemView : View):RecyclerView.ViewHolder(ItemView) {

        var text:TextView=ItemView.findViewById(R.id.textView)
        var text1:TextView=ItemView.findViewById(R.id.textView2)
        var  text2:TextView=ItemView.findViewById(R.id.lang)
        var text3:TextView=ItemView.findViewById(R.id.Rating_Point)
        var image:ImageView=ItemView.findViewById(R.id.Image_View)
        var cardView:CardView=ItemView.findViewById(R.id.CardView_1)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        var view=LayoutInflater.from(parent.context).inflate(R.layout.demo,parent,false)
        return MyViewHolder(view)

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        var ItemViewModel=mlist[position]
        holder.text.text=ItemViewModel.text
        holder.text1.text=ItemViewModel.text1
        holder.text2.text=ItemViewModel.text2
        holder.text3.text= ItemViewModel.text3
        Glide.with(context).load(mlist[position].image).into(holder.image);
        holder.cardView.setOnClickListener {
            var intent=Intent(context,MainActivity2::class.java)
            intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
            intent.putExtra("key",""+ItemViewModel.text)
            intent.putExtra("key1",""+ItemViewModel.text3)
            intent.putExtra("key2",""+ItemViewModel.image)
            intent.putExtra("key3",""+ItemViewModel.image1)
            intent.putExtra("key4",""+ItemViewModel.text4)
            intent.putExtra("key5",""+ItemViewModel.text5)
            context.startActivity(intent)

        }

    }

    override fun getItemCount(): Int {
        return mlist.size
    }
}