package com.hello.cardview_imageoverflow

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.youtube.player.YouTubeBaseActivity
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import com.google.android.youtube.player.YouTubePlayerView

class Play_video : YouTubeBaseActivity() {


    var Youtube_Api_Key ="AIzaSyD2yC682oKhfml77M9rcig5nZJOoIjdouc"

    private lateinit var youtubePlayer: YouTubePlayerView
    private lateinit var btnPlay: Button
    private lateinit var youtubePlayerInit:YouTubePlayer.OnInitializedListener
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play_video)

        var Video_Id:String=intent.getStringExtra("key").toString()
        youtubePlayer=findViewById(R.id.youtubePlayer)
        btnPlay=findViewById(R.id.btnPlay)

        youtubePlayerInit = object : YouTubePlayer.OnInitializedListener{
            override fun onInitializationSuccess(
                p0: YouTubePlayer.Provider?,
                p1: YouTubePlayer?,
                p2: Boolean
            ) {
                p1?.loadVideo(Video_Id)
            }

            override fun onInitializationFailure(
                p0: YouTubePlayer.Provider?,
                p1: YouTubeInitializationResult?
            ) {

                Toast.makeText(applicationContext, "Failed", Toast.LENGTH_SHORT).show()

            }
        }

        btnPlay.setOnClickListener {
            youtubePlayer.initialize(Youtube_Api_Key, youtubePlayerInit)

        }


    }
}