package com.hello.cardview_imageoverflow

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class Demo_Adapter2(var mlist:List<ItemViewModel2>,var context: Context):RecyclerView.Adapter<Demo_Adapter2.MyViewholder>() {
    class MyViewholder(itemview:View):RecyclerView.ViewHolder(itemview) {

        var text:TextView=itemview.findViewById(R.id.text_name)
        var image:ImageView=itemview.findViewById(R.id.Image_Dic)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewholder {
        var view=LayoutInflater.from(parent.context).inflate(R.layout.demo2,parent,false)
        return MyViewholder(view)
    }

    override fun onBindViewHolder(holder: MyViewholder, position: Int) {

        var ItemViewModel2 =mlist[position]
        holder.text.text=ItemViewModel2.text
        Glide.with(context).load(mlist[position].image).into(holder.image)
    }

    override fun getItemCount(): Int {
        return mlist.size
    }
}