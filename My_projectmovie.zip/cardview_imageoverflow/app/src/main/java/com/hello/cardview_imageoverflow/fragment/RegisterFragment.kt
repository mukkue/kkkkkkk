package com.hello.cardview_imageoverflow.fragment

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.hello.cardview_imageoverflow.R
import com.hello.cardview_imageoverflow.SqliteDataBaseAdapter


class RegisterFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view= inflater.inflate(R.layout.fragment_register, container, false)
        var name: EditText =view.findViewById(R.id.name1)
        var email: EditText =view.findViewById(R.id.email2)
        var pass: EditText =view.findViewById(R.id.pass)
        var mobile:EditText=view.findViewById(R.id.mobile)
        var btn: Button =view.findViewById(R.id.register_btn)
        var sqlite= context?.let { SqliteDataBaseAdapter(it) }
        btn.setOnClickListener{
            var name1=name.text.toString()
            var email1=email.text.toString()
            var pass1=pass.text.toString()
            var mobile1=mobile.text.toString()


            sqlite?.insertdata(name1,email1,pass1,mobile1)
            Toast.makeText(context, "Successfully update", Toast.LENGTH_SHORT).show()
        }
        return view
    }



}
