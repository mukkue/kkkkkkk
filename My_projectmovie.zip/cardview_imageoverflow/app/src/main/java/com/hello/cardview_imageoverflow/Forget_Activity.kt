package com.hello.cardview_imageoverflow

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Forget_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget)

        var email3: EditText=findViewById(R.id.email_f)
        var conpass1: EditText =findViewById(R.id.confirm_password)
        var sqlitefor= this?.let { SqliteDataBaseAdapter(it) }
        var btn3: Button =findViewById(R.id.Update_password)
        btn3.setOnClickListener {
            sqlitefor?.ForgetData(email3.text.toString(),conpass1.text.toString())
            Toast.makeText( applicationContext, "Successfully_Update", Toast.LENGTH_SHORT).show()
        }


    }
}