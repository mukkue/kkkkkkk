package com.hello.cardview_imageoverflow

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.hello.cardview_imageoverflow.fragment.LoginFragment

class Activity_Profile : AppCompatActivity() {

    lateinit var profile:TextView
    lateinit var emailuser:TextView

    private val sharedPrefFile = "kotlinsharedpreference"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val sharedPreferences: SharedPreferences = getSharedPreferences(sharedPrefFile,Context.MODE_PRIVATE)

        var sqlite= applicationContext?.let { SqliteDataBaseAdapter(it) }

        var back:ImageView=findViewById(R.id.imageBackButton)
        back.setOnClickListener {
            var intent=Intent(this,MainActivity::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }

        var logout:ImageView=findViewById(R.id.imageLogOutButton)
        logout.setOnClickListener {

            val editor:SharedPreferences.Editor =  sharedPreferences.edit()
            editor.remove("email")
            editor.apply()

            var intent=Intent(this,MainActivity::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)

        }

         profile=findViewById(R.id.profile_name)
         emailuser=findViewById(R.id.profile_email)


        var email:TextView=findViewById(R.id.profilEmailXml)
        var name:TextView=findViewById(R.id.profileNameXml)
        var num:TextView=findViewById(R.id.profileNumberXml)

        var sharedNameValue: String? = sharedPreferences.getString("email","0")


        var nn: Cursor? =sqlite?.getProfile(sharedNameValue.toString());

     nn?.moveToFirst();
        if (nn != null) {
            do {
                try {
                    name.setText(nn.getString(0))
                    profile.setText(nn.getString(0))


                    num.setText(nn.getString(3))


                }catch (e:Exception){}

            }while (nn.moveToNext())
        };

        if(sharedNameValue!="0"){

            email.setText(" ${sharedNameValue}").toString()
            emailuser.setText(sharedNameValue)

        }else{
           email.setText(sharedNameValue).toString()

        }

    }
}