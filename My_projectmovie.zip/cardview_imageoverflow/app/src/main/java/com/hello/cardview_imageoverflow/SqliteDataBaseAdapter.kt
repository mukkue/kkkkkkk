package com.hello.cardview_imageoverflow

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.StatFs
import com.hello.cardview_imageoverflow.fragment.LoginFragment
import com.hello.cardview_imageoverflow.fragment.RegisterFragment

class SqliteDataBaseAdapter(context: Context):SQLiteOpenHelper(context,"Student",null,2) {
    override fun onCreate(sqldata: SQLiteDatabase?) {

        sqldata?.execSQL("create table record(name varchar,email varchar,pass varchar,mobile varchar)")

    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {


    }

    fun insertdata(n:String,e:String,p:String,m:String)
    {
        var Sql=writableDatabase
        var contentValues=ContentValues()
        contentValues.put("name",n)
        contentValues.put("email",e)
        contentValues.put("pass",p)
        contentValues.put("mobile",m)
        Sql.insert("record",null,contentValues)
    }
    fun LoginData(email:String,pass:String): Cursor? {
        var sql=readableDatabase
        var cc=sql.rawQuery("select * from record where email='"+email+"' and pass='"+pass+"'",null)
        return cc
    }

    fun ForgetData(e:String,p:String)
    {
        var Sql1=readableDatabase
        Sql1.execSQL("update record set pass='"+p+"' where email='"+e+"'")

    }

    fun getProfile(em:String): Cursor? {
        var sql=readableDatabase
        var cc=sql.rawQuery("select * from record where email='"+em+"'",null)
        return cc
    }

}
