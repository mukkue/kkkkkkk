package com.hello.cardview_imageoverflow

class ItemViewModel2(var image:String,var text:String) {
}