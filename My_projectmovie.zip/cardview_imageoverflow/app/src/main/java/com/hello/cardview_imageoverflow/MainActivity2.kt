package com.hello.cardview_imageoverflow

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.demo.*
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Text

class MainActivity2 : AppCompatActivity() {

    var key:String?=null
    var id2:String?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var text:TextView=findViewById(R.id.textView11)
        var text1:TextView=findViewById(R.id.textView44)
        var text2:TextView=findViewById(R.id.run_time)
        var text3:TextView=findViewById(R.id.textView27)
        var text5:TextView=findViewById(R.id.textview66)
        var text6:TextView=findViewById(R.id.textView77)
        var image:ImageView=findViewById(R.id.Image_View11)
        var image1:ImageView=findViewById(R.id.Image_View22)
        var card:CardView=findViewById(R.id.Play_Now)
        var card1:CardView=findViewById(R.id.Card_back)

        var recyclerView:RecyclerView=findViewById(R.id.Recyler_dic)
        var recyclerView1:RecyclerView=findViewById(R.id.Recyler_dic1)
        recyclerView.layoutManager=LinearLayoutManager(this)
        recyclerView1.layoutManager=LinearLayoutManager(this)

        var title:String=intent.getStringExtra("key").toString()
        var rating_num:String=intent.getStringExtra("key1").toString()
        var image11:String=intent.getStringExtra("key2").toString()
        var image22:String=intent.getStringExtra("key3").toString()
        var overview:String=intent.getStringExtra("key4").toString()
        var id:String=intent.getStringExtra("key5").toString()

        text.setText(title)
        text5.setText(rating_num)
        text6.setText(overview)

        Glide.with(applicationContext).load(image11).into(image1)
        Glide.with(applicationContext).load(image22).into(image)

        card.setOnClickListener {
            var intent=Intent(this,Play_video::class.java)
            intent.putExtra("key",""+key)
            startActivity(intent)

        }
        card1.setOnClickListener {
            var intent=Intent(this,MainActivity::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)

        }


        var arrayList=ArrayList<ItemViewModel2>()
        var arrayList1=ArrayList<ItemViewModel2>()

        var queue1=Volley.newRequestQueue(this)
        var stringRequest1=StringRequest(Request.Method.GET,
            "https://api.themoviedb.org/3/movie/"+id+"/credits?api_key=802b2c4b88ea1183e50e6b285a27696e&language=en-US",
            { Response ->
                var jsonObject=JSONObject(Response)

             //  var jsonObject=JSONObject(Response)
                var jsonArray1=jsonObject.getJSONArray("crew")
                for (j in 0..jsonArray1.length()-1){

                    var jsonObj=jsonArray1.getJSONObject(j)
                    /*id2=jsonObj.getString("id")
                    var dd=jsonObj.getString("name")
                    text1.setText(dd)*/
                    var job=jsonObj.getString("job")
                 //   Toast.makeText(applicationContext, ""+job, Toast.LENGTH_SHORT).show()
                     if(job.equals("Director")){
                         var name1=jsonObj.getString("name")
                         text1.setText(name1)
                     }

                    var name1=jsonObj.getString("name")

                    var id=jsonObj.getString("id")

                    var img1="https://image.tmdb.org/t/p/w500/"+jsonObj.getString("profile_path")

                    arrayList1.add(ItemViewModel2(img1,name1))
                    var adapter=Demo_Adapter2(arrayList1,applicationContext)
                    recyclerView1.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
                    recyclerView1.adapter=adapter

                }

                var jsonArray=jsonObject.getJSONArray("cast")
                for (k in 0..jsonArray.length()-1) {
                    var jsonObject=jsonArray.getJSONObject(k)
                    var name = jsonObject.getString("name")
                    var img="https://image.tmdb.org/t/p/w500/"+jsonObject.getString("profile_path")
                 //   text1.setText(name)
                    arrayList.add(ItemViewModel2(img,name))
                    var adapter=Demo_Adapter2(arrayList,applicationContext)
                    recyclerView.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
                    recyclerView.adapter=adapter
                }
            },
            {
                Toast.makeText(applicationContext, "Not Working", Toast.LENGTH_SHORT).show()
            })
        queue1.add(stringRequest1)


        var queue= Volley.newRequestQueue(this)
        var stringRequest= StringRequest(
            Request.Method.GET,
            "http://api.themoviedb.org/3/movie/"+id+"?api_key=802b2c4b88ea1183e50e6b285a27696e",
            { Response->
                var jsonObject= JSONObject(Response)
                var runtime:String=jsonObject.getString("runtime")
                var aa:Int=runtime.toInt()
                val ss=aa/60
                val ss1=aa%60
                text2.setText(ss.toString()+"H"+" "+ss1+"min")
                var jsonArray=jsonObject.getJSONArray("genres")
                for (i in 0..jsonArray.length()-1){

                    var jsonObject=jsonArray.getJSONObject(i);
                    var name=jsonObject.getString("name")+",";
                    text3.append(name)
                  //  Toast.makeText(applicationContext, ""+i, Toast.LENGTH_SHORT).show()

                }
            },
            {
                Toast.makeText(applicationContext, "Not Working", Toast.LENGTH_SHORT).show()
            })

        queue.add(stringRequest)

        var queue2=Volley.newRequestQueue(this)
        var stringRequest2=StringRequest(Request.Method.GET,
            "https://api.themoviedb.org/3/movie/"+id+"/videos?api_key=802b2c4b88ea1183e50e6b285a27696e&language=en-US",
            { Response ->
                var jsonObject=JSONObject(Response)
                var jsonArray=jsonObject.getJSONArray("results")
                for (j in 0..jsonArray.length()-1)
                {
                    var jsonObject=jsonArray.getJSONObject(j)
                    key=jsonObject.getString("key")

                }

        },
            {
                Toast.makeText(applicationContext, "Not Working", Toast.LENGTH_SHORT).show()
        })
        queue2.add(stringRequest2)

    }
}