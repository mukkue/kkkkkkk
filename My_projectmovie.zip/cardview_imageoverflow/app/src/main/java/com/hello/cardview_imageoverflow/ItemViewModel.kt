package com.hello.cardview_imageoverflow

import org.json.JSONArray

class ItemViewModel(
    var text:String,
    var image:String,
    var text3:String,
    var text1:String,
    var text2:String,
    var image1:String,
    var text4:String,
    var text5:String
){
}