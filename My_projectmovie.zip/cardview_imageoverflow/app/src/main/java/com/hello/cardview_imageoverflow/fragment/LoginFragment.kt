package com.hello.cardview_imageoverflow.fragment

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.hello.cardview_imageoverflow.Forget_Activity
import com.hello.cardview_imageoverflow.R
import com.hello.cardview_imageoverflow.SqliteDataBaseAdapter


class LoginFragment : Fragment() {
    private val sharedPrefFile = "kotlinsharedpreference"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

       var view= inflater.inflate(R.layout.fragment_login, container, false)
        val sharedPreferences: SharedPreferences = requireContext().getSharedPreferences(sharedPrefFile,Context.MODE_PRIVATE)
        var email2:EditText=view.findViewById(R.id.email)
        var pass2:EditText=view.findViewById(R.id.password)
        var forget:Button=view.findViewById(R.id.forget_tv)
        var sqlitelogin= context?.let { SqliteDataBaseAdapter(it) }
        var btn2:Button=view.findViewById(R.id.login_btn)
        btn2.setOnClickListener {
            var em = email2.text.toString()
            var pas = pass2.text.toString()

            var cc=sqlitelogin?.LoginData(em,pas)
            var count=cc?.count
            if (count==1){
                val editor:SharedPreferences.Editor =  sharedPreferences.edit()
                editor.putString("email",em)
                editor.apply()
                editor.commit()
                Toast.makeText(context, "Sussecfully Login", Toast.LENGTH_SHORT).show()
            }
            else
            {
                Toast.makeText(context, "Wrong email and password", Toast.LENGTH_SHORT).show()
            }

        }

        forget.setOnClickListener{

            var intent=Intent(context,Forget_Activity::class.java)
            startActivity(intent)

        }
        return view;


    }

}
