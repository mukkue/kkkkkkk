package com.hello.cardview_imageoverflow.adapters

import android.content.Context
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.hello.cardview_imageoverflow.fragment.LoginFragment
import com.hello.cardview_imageoverflow.fragment.RegisterFragment

class LoginAdapter(fragmentManager: FragmentManager,lifecycle: Lifecycle) :
    FragmentStateAdapter(fragmentManager,lifecycle) {
    override fun getItemCount(): Int {

        return 2

    }

    override fun createFragment(position: Int): Fragment {

        when(position){
            0-> return LoginFragment()
            1-> return RegisterFragment()
            else -> return LoginFragment()
        }
    }

}