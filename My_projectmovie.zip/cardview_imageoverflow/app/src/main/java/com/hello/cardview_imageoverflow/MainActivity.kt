package com.hello.cardview_imageoverflow

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.Cursor
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*

import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity() {


    lateinit var toggle: ActionBarDrawerToggle

    private val sharedPrefFile = "kotlinsharedpreference"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var image: ImageView = findViewById(R.id.menu_drawar)
        image.setOnClickListener {
            my_drawar_layout.openDrawer(Gravity.START)


        }

        val sharedPreferences: SharedPreferences = getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)

        var sqlite= applicationContext?.let { SqliteDataBaseAdapter(it) }

        var sharedNameValue: String? = sharedPreferences.getString("email","0")


        var nn: Cursor? =sqlite?.getProfile(sharedNameValue.toString());


        val hView = navigationview.getHeaderView(0)
        val textViewName = hView.findViewById(R.id.text_view1) as TextView

        val textViewEmail = hView.findViewById(R.id.tttt) as TextView
        val imgvw = hView.findViewById(R.id.image_view) as ImageView

        nn?.moveToFirst();
        if (nn != null) {
            do {
                try {
                    textViewName.setText(nn.getString(0))
                   // profile.setText(nn.getString(0))


                   // num.setText(nn.getString(3))


                }catch (e:Exception){}

            }while (nn.moveToNext())
        };

        if(sharedNameValue!="0"){

            textViewEmail.setText(" ${sharedNameValue}").toString()
           // emailuser.setText(sharedNameValue)

        }else{
            textViewEmail.setText(sharedNameValue).toString()

        }




        /*val profile_:String=intent.getStringExtra("profile").toString()
        Toast.makeText(applicationContext, ""+profile_, Toast.LENGTH_SHORT).show()
        textViewName.setText(profile_)*/



        var account: ImageView = findViewById(R.id.imageView3)
        account.setOnClickListener {
            var intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)

        }


        var recyclerView: RecyclerView = findViewById(R.id.RecylerView_)
        recyclerView.layoutManager = LinearLayoutManager(this)

        var drawerLayout: DrawerLayout = findViewById(R.id.my_drawar_layout)
        toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            R.string.nav_open,
            R.string.nav_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        var nav: NavigationView = findViewById(R.id.navigationview)
        nav.setNavigationItemSelectedListener(NavigationView.OnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home) {
                Toast.makeText(applicationContext, "Home", Toast.LENGTH_SHORT).show()
                var intent = Intent(this, MainActivity::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
            } else if (item.itemId == R.id.second) {
                Toast.makeText(applicationContext, "PlayList", Toast.LENGTH_SHORT).show()
            } else if (item.itemId == R.id.third) {
                Toast.makeText(applicationContext, "Setting", Toast.LENGTH_SHORT).show()
            }

            true
        })


        //bottomnavigationbar

        val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home1 -> {
                    // put your code here
                    Toast.makeText(this, "home", Toast.LENGTH_SHORT).show()
                    var intent=Intent(this,MainActivity::class.java)
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(intent)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.bookmark1 -> {
                    // put your code here
                    Toast.makeText(this, "bookmark", Toast.LENGTH_SHORT).show()

                    return@OnNavigationItemSelectedListener true
                    }
                R.id.explore1 -> {
                    // put your code here
                    Toast.makeText(this, "explore", Toast.LENGTH_SHORT).show()
                    return@OnNavigationItemSelectedListener true
                }
                R.id.account1 -> {
                    // put your code here
                  //  Toast.makeText(this, "account", Toast.LENGTH_SHORT).show()
                   var intent=Intent(applicationContext,Activity_Profile::class.java)
                    startActivity(intent)
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }
        Bottom_navigationview.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        var queue = Volley.newRequestQueue(this)
        var arraylist = ArrayList<ItemViewModel>()
        var stringRequest = StringRequest(
            Request.Method.GET,
                "http://api.themoviedb.org/3/movie/popular?api_key=802b2c4b88ea1183e50e6b285a27696e",
            { Response ->

                var jsonObject = JSONObject(Response)
                var Jsonarray = jsonObject.getJSONArray("results")
                for (i in 0..Jsonarray.length() - 1) {

                    val name = Jsonarray.getJSONObject(i)
                    var title = name.getString("title")
                    var rating = name.getString("vote_average")
                    var img = "https://image.tmdb.org/t/p/w500/" + name.getString("poster_path")
                    var img1 = "https://image.tmdb.org/t/p/w500/" + name.getString("backdrop_path")

                    //Release date change format
                    var date = name.getString("release_date")
                    var date1 = LocalDate.parse(date)
                    var formatter = DateTimeFormatter.ofPattern("dd MMMM,yyyy")
                    var formattedDate = date1.format(formatter)

                    var language = name.getString("original_language")
                    var overview = name.getString("overview")

                    var id = name.getString("id")

                    arraylist.add(
                        ItemViewModel(
                            title,
                            img,
                            rating,
                            formattedDate,
                            language,
                            img1,
                            overview,
                            id
                        )
                    )
                    var adapter = Demo_Adapter(arraylist, applicationContext)
                    recyclerView.layoutManager = GridLayoutManager(this, 1)
                    recyclerView.adapter = adapter

                }
            },
            {

                Toast.makeText(applicationContext, "Not Working", Toast.LENGTH_SHORT).show()
            })

        queue.add(stringRequest)

    }

}
