package com.hello.cardview_imageoverflow

class ItemViewModel (var text:String,var text1:String,var text2:String,var text3:String ,var image:Int){
}